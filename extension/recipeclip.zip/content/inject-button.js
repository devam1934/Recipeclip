// src/shared/messages.ts
function isMessage(value) {
  return typeof value === "object" && value !== null && typeof value.type === "string";
}

// src/youtube/transcript.ts
var NoTranscriptError = class extends Error {
  constructor(message = "This video has no transcript available.") {
    super(message);
    this.name = "NoTranscriptError";
  }
};
var NotAVideoError = class extends Error {
  constructor(message = "No YouTube video found on this page.") {
    super(message);
    this.name = "NotAVideoError";
  }
};
var TranscriptManualError = class extends Error {
  constructor(message = "Open this video's transcript, then click Get recipe again.") {
    super(message);
    this.name = "TranscriptManualError";
  }
};
var PAGE_READER_MESSAGE_TAG = "recipeclip-page-reader";
var PAGE_READER_PATH = "youtube/page-reader.js";
var PAGE_READER_TIMEOUT_MS = 3e3;
var PANEL_WAIT_MS = 12e3;
async function gatherVideoData() {
  const player = await getPlayerResponse();
  const videoId = player?.videoDetails?.videoId ?? getVideoIdFromUrl();
  if (!videoId) throw new NotAVideoError();
  const title = player?.videoDetails?.title ?? document.title.replace(/ - YouTube$/, "").trim();
  const description = player?.videoDetails?.shortDescription ?? "";
  const segments = await getTranscript(player);
  console.info("[RecipeClip] gathered", {
    videoId,
    title,
    descriptionChars: description.length,
    segments: segments.length
  });
  if (segments.length === 0) {
    const hasCaptions = !!player?.captions?.playerCaptionsTracklistRenderer?.captionTracks?.length;
    if (hasCaptions) throw new TranscriptManualError();
    if (description.trim() === "") {
      throw new NoTranscriptError(
        "This video has no transcript or description to read a recipe from."
      );
    }
  }
  return { videoId, title, description, segments };
}
async function getPlayerResponse() {
  const fromPage = await readPlayerResponseFromPage();
  if (fromPage) return fromPage;
  return parseInlinePlayerResponse();
}
function readPlayerResponseFromPage() {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      window.removeEventListener("message", onMessage);
      resolve(value);
    };
    const onMessage = (event) => {
      if (event.source !== window) return;
      const data = event.data;
      if (!data || data.__recipeclip !== PAGE_READER_MESSAGE_TAG) return;
      finish(data.playerResponse ?? null);
    };
    window.addEventListener("message", onMessage);
    const script = document.createElement("script");
    script.src = chrome.runtime.getURL(PAGE_READER_PATH);
    script.onload = () => script.remove();
    (document.head ?? document.documentElement).appendChild(script);
    setTimeout(() => finish(null), PAGE_READER_TIMEOUT_MS);
  });
}
function parseInlinePlayerResponse() {
  for (const script of Array.from(document.scripts)) {
    const text = script.textContent;
    if (!text || !text.includes("ytInitialPlayerResponse")) continue;
    const start = text.indexOf("{", text.indexOf("ytInitialPlayerResponse"));
    if (start === -1) continue;
    const json = sliceBalancedJson(text, start);
    if (!json) continue;
    try {
      return JSON.parse(json);
    } catch {
    }
  }
  return null;
}
function sliceBalancedJson(text, start) {
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') inString = true;
    else if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth === 0) return text.slice(start, i + 1);
    }
  }
  return null;
}
async function getTranscript(player) {
  const tracks = player?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
  console.debug("[RecipeClip] caption tracks available:", tracks?.length ?? 0);
  const track = pickCaptionTrack(tracks);
  if (track) {
    try {
      const segments = await fetchCaptionTrack(track.baseUrl);
      console.debug("[RecipeClip] json3 caption segments:", segments.length);
      if (segments.length > 0) return segments;
    } catch (err) {
      console.debug("[RecipeClip] caption fetch failed, will scrape panel:", err);
    }
  }
  console.debug("[RecipeClip] falling back to transcript-panel scrape");
  const scraped = await scrapeTranscriptPanel();
  console.debug("[RecipeClip] transcript-panel segments:", scraped.length);
  return scraped;
}
function pickCaptionTrack(tracks) {
  if (!tracks || tracks.length === 0) return null;
  const isEnglish = (t) => t.languageCode?.startsWith("en");
  return tracks.find((t) => isEnglish(t) && t.kind !== "asr") ?? tracks.find(isEnglish) ?? tracks[0];
}
async function fetchCaptionTrack(baseUrl) {
  const url = new URL(baseUrl, window.location.origin);
  url.searchParams.set("fmt", "json3");
  const res = await fetch(url.toString(), { credentials: "include" });
  if (!res.ok) throw new Error(`caption fetch failed: ${res.status}`);
  const raw = await res.text();
  if (!raw.trim()) {
    console.debug("[RecipeClip] caption endpoint returned an empty body");
    return [];
  }
  const data = JSON.parse(raw);
  const segments = [];
  for (const event of data.events ?? []) {
    const text = (event.segs ?? []).map((s) => s.utf8 ?? "").join("").replace(/\s+/g, " ").trim();
    if (!text) continue;
    segments.push({ start: Math.round((event.tStartMs ?? 0) / 1e3), text });
  }
  return segments;
}
async function scrapeTranscriptPanel() {
  await openTranscriptPanel();
  const rows = await waitForStableSegments(PANEL_WAIT_MS);
  const segments = [];
  for (const row of rows) {
    const stamp = row.querySelector(".segment-timestamp")?.textContent?.trim();
    const text = row.querySelector(".segment-text")?.textContent?.trim();
    if (!text) continue;
    segments.push({ start: parseTimestamp(stamp ?? "0"), text });
  }
  return segments;
}
async function openTranscriptPanel() {
  if (document.querySelector("ytd-transcript-segment-renderer")) return;
  const expand = document.querySelector(
    "tp-yt-paper-button#expand, #expand, #description #expand"
  );
  expand?.click();
  await delay(300);
  const button = findButtonByText(["show transcript", "transcript"]);
  if (!button) {
    console.warn("[RecipeClip] could not find a 'Show transcript' button");
    return;
  }
  button.click();
  await delay(500);
}
function findButtonByText(phrases) {
  const candidates = Array.from(
    document.querySelectorAll("button, a, tp-yt-paper-item, yt-button-shape")
  );
  for (const el of candidates) {
    const label = (el.getAttribute("aria-label") ?? el.textContent ?? "").toLowerCase();
    if (phrases.some((p) => label.includes(p))) return el;
  }
  return null;
}
function waitForStableSegments(timeoutMs) {
  const SELECTOR = "ytd-transcript-segment-renderer";
  return new Promise((resolve) => {
    const start = Date.now();
    let lastCount = -1;
    let stableTicks = 0;
    const tick = () => {
      const found = Array.from(document.querySelectorAll(SELECTOR));
      if (found.length > 0 && found.length === lastCount) {
        if (++stableTicks >= 3) return resolve(found);
      } else {
        stableTicks = 0;
      }
      lastCount = found.length;
      if (Date.now() - start >= timeoutMs) return resolve(found);
      setTimeout(tick, 300);
    };
    tick();
  });
}
function parseTimestamp(stamp) {
  const parts = stamp.split(":").map((p) => parseInt(p, 10));
  if (parts.some(Number.isNaN)) return 0;
  return parts.reduce((acc, n) => acc * 60 + n, 0);
}
function getVideoIdFromUrl() {
  return new URL(window.location.href).searchParams.get("v");
}
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// src/content/inject-button.ts
var BUTTON_ID = "recipeclip-get-recipe";
function extensionAlive() {
  return Boolean(chrome.runtime?.id);
}
function send(message) {
  if (!extensionAlive()) return;
  try {
    void chrome.runtime.sendMessage(message)?.catch(() => {
    });
  } catch {
  }
}
function createButton() {
  const button = document.createElement("button");
  button.id = BUTTON_ID;
  button.textContent = "\u{1F373} Get recipe";
  button.style.cssText = [
    "display:inline-flex",
    "align-items:center",
    "gap:6px",
    "margin:8px 0",
    "padding:8px 14px",
    "font:500 14px/1 Roboto, Arial, sans-serif",
    "color:#0f0f0f",
    "background:#ff5722",
    "color:#fff",
    "border:none",
    "border-radius:18px",
    "cursor:pointer"
  ].join(";");
  button.addEventListener("click", onClick);
  return button;
}
async function onClick(event) {
  const button = event.currentTarget;
  if (!extensionAlive()) {
    button.textContent = "\u21BB Refresh page to use";
    return;
  }
  button.disabled = true;
  const original = button.textContent;
  button.textContent = "Reading\u2026";
  send({ type: "PANEL_OPEN" });
  try {
    const request = await gatherVideoData();
    send({ type: "EXTRACT_REQUEST", request });
  } catch (err) {
    if (err instanceof TranscriptManualError) {
      send({
        type: "GATHER_ERROR",
        code: "no_transcript",
        message: "This video's transcript didn't load automatically. Open it on the video (click \u201C\u2026more\u201D, then \u201CShow transcript\u201D), then click Get recipe again \u2014 it's a one-time step and the recipe is saved after."
      });
    } else if (err instanceof NoTranscriptError) {
      send({ type: "GATHER_ERROR", code: "no_transcript", message: err.message });
    } else if (err instanceof NotAVideoError) {
      send({ type: "GATHER_ERROR", code: "bad_request", message: err.message });
    } else {
      send({
        type: "GATHER_ERROR",
        code: "internal_error",
        message: "Couldn't read the video data."
      });
    }
  } finally {
    button.disabled = false;
    button.textContent = original;
  }
}
function findTitleAnchor() {
  return document.querySelector(
    "ytd-watch-metadata #title, #above-the-fold #title"
  );
}
function placeNearTitle(button, anchor) {
  button.dataset.placement = "title";
  button.style.position = "";
  button.style.bottom = "";
  button.style.right = "";
  anchor.appendChild(button);
}
function placeFloating(button) {
  button.dataset.placement = "float";
  button.style.position = "fixed";
  button.style.bottom = "16px";
  button.style.right = "16px";
  button.style.zIndex = "9999";
  document.body.appendChild(button);
}
function injectButton() {
  const existing = document.getElementById(BUTTON_ID);
  const anchor = findTitleAnchor();
  if (existing) {
    if (anchor && existing.dataset.placement === "float") {
      placeNearTitle(existing, anchor);
    }
    return;
  }
  const button = createButton();
  if (anchor) placeNearTitle(button, anchor);
  else placeFloating(button);
}
function seekTo(seconds) {
  const video = document.querySelector("video");
  if (!video) return;
  video.currentTime = seconds;
  void video.play().catch(() => {
  });
  video.scrollIntoView({ behavior: "smooth", block: "center" });
}
chrome.runtime.onMessage.addListener((raw) => {
  if (isMessage(raw) && raw.type === "SEEK") seekTo(raw.seconds);
});
document.addEventListener("yt-navigate-finish", () => injectButton());
var observer = new MutationObserver(() => {
  if (!extensionAlive()) {
    observer.disconnect();
    return;
  }
  injectButton();
});
observer.observe(document.documentElement, { childList: true, subtree: true });
injectButton();
//# sourceMappingURL=inject-button.js.map
