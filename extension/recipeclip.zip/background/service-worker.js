// src/shared/config.ts
var BACKEND_URL = "https://recipeclip-backend.nanavatidevam.workers.dev";
var SHOP_URL = `${BACKEND_URL}/shop`;
var SUBSTITUTE_URL = `${BACKEND_URL}/substitute`;

// src/shared/messages.ts
function isMessage(value) {
  return typeof value === "object" && value !== null && typeof value.type === "string";
}

// src/background/service-worker.ts
var currentState = { status: "idle" };
function setState(state) {
  currentState = state;
  chrome.runtime.sendMessage({ type: "STATE_UPDATE", state }).catch(() => {
  });
}
chrome.runtime.onMessage.addListener((raw, sender, sendResponse) => {
  if (!isMessage(raw)) return;
  switch (raw.type) {
    case "PANEL_OPEN":
      openPanel(sender.tab);
      setState({ status: "loading" });
      return;
    case "EXTRACT_REQUEST":
      setState({ status: "loading", title: raw.request.title });
      void runExtraction(raw.request);
      return;
    case "GATHER_ERROR":
      setState({ status: "error", code: raw.code, message: raw.message });
      return;
    case "GET_STATE":
      sendResponse(currentState);
      return;
    // synchronous response
    case "SEEK":
      void seekActiveTab(raw.seconds);
      return;
  }
});
function openPanel(tab) {
  if (!tab?.id) return;
  chrome.sidePanel.open({ tabId: tab.id }).catch((err) => {
    console.error("[RecipeClip] could not open side panel:", err);
  });
}
var REQUEST_TIMEOUT_MS = 45e3;
async function runExtraction(request) {
  const timeout = AbortSignal.timeout(REQUEST_TIMEOUT_MS);
  try {
    const res = await fetch(BACKEND_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request),
      signal: timeout
    });
    const data = await res.json();
    if (data.ok) {
      setState({
        status: "ready",
        recipe: data.recipe,
        videoId: request.videoId,
        cached: data.cached
      });
    } else {
      setState({ status: "error", code: data.error, message: data.message });
    }
  } catch (err) {
    const timedOut = err instanceof DOMException && err.name === "TimeoutError";
    setState({
      status: "error",
      code: "internal_error",
      message: timedOut ? "The backend took too long to respond. Try again." : "Couldn't reach the RecipeClip backend. Is it running?"
    });
  }
}
async function seekActiveTab(seconds) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) {
    chrome.tabs.sendMessage(tab.id, { type: "SEEK", seconds }).catch(() => {
    });
  }
}
//# sourceMappingURL=service-worker.js.map
