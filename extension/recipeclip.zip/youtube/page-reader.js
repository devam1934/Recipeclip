"use strict";
(() => {
  // src/youtube/page-reader.ts
  var MESSAGE_TAG = "recipeclip-page-reader";
  (function emitPlayerResponse() {
    let playerResponse = null;
    try {
      const player = document.querySelector(
        "#movie_player, .html5-video-player"
      );
      if (player && typeof player.getPlayerResponse === "function") {
        playerResponse = player.getPlayerResponse();
      }
    } catch {
    }
    if (!playerResponse) {
      playerResponse = window.ytInitialPlayerResponse ?? null;
    }
    window.postMessage(
      { __recipeclip: MESSAGE_TAG, playerResponse },
      window.location.origin
    );
  })();
})();
//# sourceMappingURL=page-reader.js.map
