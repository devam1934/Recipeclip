// src/shared/config.ts
var BACKEND_URL = "https://recipeclip-backend.nanavatidevam.workers.dev";
var SHOP_URL = `${BACKEND_URL}/shop`;
var SUBSTITUTE_URL = `${BACKEND_URL}/substitute`;

// src/shared/messages.ts
function isMessage(value) {
  return typeof value === "object" && value !== null && typeof value.type === "string";
}

// src/sidepanel/export.ts
function toMarkdown(recipe2) {
  const lines = [];
  lines.push(`# ${recipe2.title || "Untitled recipe"}`);
  const meta = [
    recipe2.servings ? `Serves ${recipe2.servings}` : null,
    recipe2.totalTime,
    recipe2.difficulty,
    recipe2.cuisine
  ].filter(Boolean);
  if (meta.length) lines.push("", `_${meta.join(" \xB7 ")}_`);
  if (recipe2.summary) lines.push("", recipe2.summary);
  if (recipe2.backstory) lines.push("", `_${recipe2.backstory}_`);
  const tags = recipe2.dietaryTags ?? [];
  if (tags.length) lines.push("", `Tags: ${tags.join(", ")}`);
  const n = recipe2.nutrition;
  if (n) {
    const parts = [
      n.calories != null ? `${n.calories} kcal` : null,
      n.protein != null ? `P ${n.protein}g` : null,
      n.carbs != null ? `C ${n.carbs}g` : null,
      n.fat != null ? `F ${n.fat}g` : null
    ].filter(Boolean);
    if (parts.length) lines.push("", `Nutrition (per serving, est.): ${parts.join(" \xB7 ")}`);
  }
  if (recipe2.chefTip) lines.push("", `**Tip:** ${recipe2.chefTip}`);
  if (recipe2.ingredients.length) {
    lines.push("", "## Ingredients", "");
    for (const ing of recipe2.ingredients) {
      const qty = [ing.amount, ing.unit].filter(Boolean).join(" ");
      const flag = ing.uncertain ? " _(approx)_" : "";
      lines.push(`- ${[qty, ing.name].filter(Boolean).join(" ")}${flag}`);
    }
  }
  if (recipe2.steps.length) {
    lines.push("", "## Steps", "");
    recipe2.steps.forEach((step, i) => {
      const ts = step.timestamp !== null ? ` _(${formatTimestamp(step.timestamp)})_` : "";
      lines.push(`${i + 1}. ${step.instruction}${ts}`);
    });
  }
  if (recipe2.notes) lines.push("", "## Notes", "", recipe2.notes);
  return lines.join("\n") + "\n";
}
function formatTimestamp(totalSeconds) {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor(totalSeconds % 3600 / 60);
  const s = totalSeconds % 60;
  const mm = h > 0 ? String(m).padStart(2, "0") : String(m);
  const ss = String(s).padStart(2, "0");
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

// src/sidepanel/scale.ts
function parseLeadingQuantity(text) {
  const s = text.trimStart();
  const mixed = s.match(/^(\d+)\s+(\d+)\/(\d+)/);
  if (mixed) {
    const [whole, num, den] = [mixed[1], mixed[2], mixed[3]].map(Number);
    return { value: whole + num / den, rest: s.slice(mixed[0].length) };
  }
  const frac = s.match(/^(\d+)\/(\d+)/);
  if (frac) {
    return { value: Number(frac[1]) / Number(frac[2]), rest: s.slice(frac[0].length) };
  }
  const dec = s.match(/^\d+(?:\.\d+)?/);
  if (dec) {
    return { value: Number(dec[0]), rest: s.slice(dec[0].length) };
  }
  return null;
}
function formatQuantity(value) {
  const rounded = Math.round(value * 1e3) / 1e3;
  const whole = Math.floor(rounded);
  const frac = rounded - whole;
  if (frac < 0.02) return String(whole);
  for (const den of [2, 3, 4, 8]) {
    const num = Math.round(frac * den);
    if (num > 0 && num < den && Math.abs(frac - num / den) < 0.03) {
      const fraction = `${num}/${den}`;
      return whole > 0 ? `${whole} ${fraction}` : fraction;
    }
  }
  return String(Math.round(rounded * 100) / 100);
}
function scaleServings(servings, factor) {
  if (!servings || factor === 1) return servings;
  return servings.replace(
    /\d+(?:\.\d+)?/g,
    (n) => formatQuantity(Number(n) * factor)
  );
}

// src/sidepanel/units.ts
var UNITS = {
  // volume (base: ml)
  tsp: { type: "volume", toBase: 4.92892 },
  teaspoon: { type: "volume", toBase: 4.92892 },
  teaspoons: { type: "volume", toBase: 4.92892 },
  tbsp: { type: "volume", toBase: 14.7868 },
  tbs: { type: "volume", toBase: 14.7868 },
  tablespoon: { type: "volume", toBase: 14.7868 },
  tablespoons: { type: "volume", toBase: 14.7868 },
  cup: { type: "volume", toBase: 236.588 },
  cups: { type: "volume", toBase: 236.588 },
  "fl oz": { type: "volume", toBase: 29.5735 },
  floz: { type: "volume", toBase: 29.5735 },
  pint: { type: "volume", toBase: 473.176 },
  pints: { type: "volume", toBase: 473.176 },
  quart: { type: "volume", toBase: 946.353 },
  quarts: { type: "volume", toBase: 946.353 },
  gallon: { type: "volume", toBase: 3785.41 },
  ml: { type: "volume", toBase: 1 },
  milliliter: { type: "volume", toBase: 1 },
  millilitre: { type: "volume", toBase: 1 },
  l: { type: "volume", toBase: 1e3 },
  liter: { type: "volume", toBase: 1e3 },
  litre: { type: "volume", toBase: 1e3 },
  // weight (base: g)
  g: { type: "weight", toBase: 1 },
  gram: { type: "weight", toBase: 1 },
  grams: { type: "weight", toBase: 1 },
  kg: { type: "weight", toBase: 1e3 },
  kilogram: { type: "weight", toBase: 1e3 },
  oz: { type: "weight", toBase: 28.3495 },
  ounce: { type: "weight", toBase: 28.3495 },
  ounces: { type: "weight", toBase: 28.3495 },
  lb: { type: "weight", toBase: 453.592 },
  lbs: { type: "weight", toBase: 453.592 },
  pound: { type: "weight", toBase: 453.592 },
  pounds: { type: "weight", toBase: 453.592 }
};
function convertMeasure(amount, unit, system, scale2) {
  const parsed = amount ? parseLeadingQuantity(amount) : null;
  if (!parsed) return { amount, unit };
  const value = parsed.value * scale2;
  const info = unit ? UNITS[unit.trim().toLowerCase()] : void 0;
  if (system === "orig" || !info) {
    return { amount: formatQuantity(value) + parsed.rest, unit };
  }
  const base = value * info.toBase;
  return info.type === "volume" ? pickVolume(base, system) : pickWeight(base, system);
}
function pickVolume(ml, system) {
  if (system === "metric") {
    return ml >= 1e3 ? { amount: formatMetric(ml / 1e3), unit: "l" } : { amount: formatMetric(ml), unit: "ml" };
  }
  if (ml >= 236.588 * 0.75) return usVolume(ml / 236.588, "cup");
  if (ml >= 14.7868) return usVolume(ml / 14.7868, "tbsp");
  return usVolume(ml / 4.92892, "tsp");
}
function usVolume(value, unit) {
  const label = unit === "cup" && Math.abs(value - 1) > 0.01 ? "cups" : unit;
  return { amount: formatQuantity(value), unit: label };
}
function pickWeight(g, system) {
  if (system === "metric") {
    return g >= 1e3 ? { amount: formatMetric(g / 1e3), unit: "kg" } : { amount: formatMetric(g), unit: "g" };
  }
  const oz = g / 28.3495;
  if (oz >= 16) return { amount: formatQuantity(oz / 16), unit: "lb" };
  return { amount: formatQuantity(oz), unit: "oz" };
}
var STEP_MEASURE_RE = /(\d+\s+\d+\/\d+|\d+\/\d+|\d+(?:\.\d+)?)\s*(tablespoons?|tbsp|tbs|teaspoons?|tsp|cups?|fl\s?oz|fluid ounces?|ounces?|oz|pounds?|lbs?|lb|kilograms?|kg|grams?|g|milliliters?|ml|litres?|liters?|l|pints?|quarts?|gallons?)\b/gi;
function convertInText(text, system, scale2) {
  if (system === "orig" && scale2 === 1) return text;
  return text.replace(STEP_MEASURE_RE, (_match, qty, unit) => {
    const m = convertMeasure(qty, unit, system, scale2);
    return [m.amount, m.unit].filter(Boolean).join(" ");
  });
}
function formatMetric(value) {
  if (value >= 100) return String(Math.round(value));
  if (value >= 10) return String(Math.round(value));
  return String(Math.round(value * 10) / 10);
}

// src/sidepanel/storage.ts
var KEY_PREFIX = "recipe:";
async function saveRecipe(videoId2, recipe2) {
  const entry = { recipe: recipe2, savedAt: Date.now() };
  await chrome.storage.local.set({ [KEY_PREFIX + videoId2]: entry });
}
async function listSavedRecipes() {
  const all = await chrome.storage.local.get(null);
  const out = [];
  for (const [key, value] of Object.entries(all)) {
    if (!key.startsWith(KEY_PREFIX)) continue;
    const entry = value;
    if (entry?.recipe) {
      out.push({
        videoId: key.slice(KEY_PREFIX.length),
        recipe: entry.recipe,
        savedAt: entry.savedAt ?? 0
      });
    }
  }
  out.sort((a, b) => b.savedAt - a.savedAt);
  return out;
}
async function deleteRecipe(videoId2) {
  await chrome.storage.local.remove([KEY_PREFIX + videoId2, CHECKS_PREFIX + videoId2]);
}
var CHECKS_PREFIX = "checks:";
async function saveChecks(videoId2, checks) {
  await chrome.storage.local.set({ [CHECKS_PREFIX + videoId2]: checks });
}
async function loadChecks(videoId2) {
  const key = CHECKS_PREFIX + videoId2;
  const result = await chrome.storage.local.get(key);
  return result[key] ?? { ingredients: [], steps: [] };
}

// src/sidepanel/panel.ts
var app = document.getElementById("app");
var recipe = null;
var videoId = null;
var editMode = false;
var scale = 1;
var units = "orig";
var activeTab = "ingredients";
var libraryOpen = false;
var lastState = { status: "idle" };
var checkedIngredients = /* @__PURE__ */ new Set();
var checkedSteps = /* @__PURE__ */ new Set();
chrome.runtime.sendMessage({ type: "GET_STATE" }).then(
  (state) => handleState(state ?? { status: "idle" }),
  () => handleState({ status: "idle" })
);
chrome.runtime.onMessage.addListener((raw) => {
  if (isMessage(raw) && raw.type === "STATE_UPDATE") handleState(raw.state);
});
function handleState(state) {
  lastState = state;
  libraryOpen = false;
  if (state.status !== "ready") {
    recipe = null;
    renderRoot();
    return;
  }
  loadRecipeIntoView(structuredClone(state.recipe), state.videoId);
}
function loadRecipeIntoView(r, id) {
  recipe = r;
  videoId = id;
  editMode = false;
  scale = 1;
  units = "orig";
  activeTab = "ingredients";
  checkedIngredients.clear();
  checkedSteps.clear();
  lastState = { status: "ready", recipe: r, videoId: id, cached: true };
  renderRoot();
  void loadChecks(id).then((checks) => {
    checks.ingredients.forEach((i) => checkedIngredients.add(i));
    checks.steps.forEach((i) => checkedSteps.add(i));
    if (recipe && !libraryOpen) renderRoot();
  });
}
function renderRoot() {
  if (libraryOpen) {
    app.replaceChildren(libraryView());
  } else if (lastState.status === "ready" && recipe) {
    app.replaceChildren(card(recipe));
  } else {
    app.replaceChildren(nonReadyView(lastState));
  }
}
function nonReadyView(state) {
  switch (state.status) {
    case "loading": {
      const wrap = el("div", "state");
      wrap.appendChild(el("div", "spinner"));
      wrap.appendChild(textEl("p", state.title ? `Reading \u201C${state.title}\u201D\u2026` : "Reading recipe\u2026"));
      return wrap;
    }
    case "error":
      return message(state.message, "\u{1F615}");
    case "idle":
    default: {
      const wrap = message("Open a YouTube recipe and click \u201CGet recipe\u201D.", "\u{1F373}");
      const btn = textEl("button", "Saved recipes", "icon-btn");
      btn.style.marginTop = "12px";
      btn.addEventListener("click", openLibrary);
      wrap.appendChild(btn);
      return wrap;
    }
  }
}
function message(msg, icon) {
  const wrap = el("div", "state");
  wrap.appendChild(textEl("div", icon, "icon"));
  wrap.appendChild(textEl("p", msg));
  return wrap;
}
function libraryView() {
  const wrap = el("div", "library");
  const head = el("div", "lib-head");
  const back = textEl("button", "\u2190 Back", "icon-btn");
  back.addEventListener("click", () => {
    libraryOpen = false;
    renderRoot();
  });
  head.append(back, textEl("h1", "Saved recipes", "title"));
  wrap.appendChild(head);
  const search = document.createElement("input");
  search.type = "search";
  search.placeholder = "Search saved recipes\u2026";
  search.className = "lib-search";
  wrap.appendChild(search);
  const list = el("div", "lib-list");
  wrap.appendChild(list);
  search.addEventListener("input", () => {
    const q = search.value.trim().toLowerCase();
    list.querySelectorAll(".lib-item").forEach((item) => {
      item.style.display = (item.dataset.title ?? "").includes(q) ? "" : "none";
    });
  });
  void listSavedRecipes().then((entries) => {
    if (entries.length === 0) {
      list.appendChild(textEl("p", "No saved recipes yet.", "summary"));
      return;
    }
    for (const entry of entries) list.appendChild(libraryItem(entry));
  });
  return wrap;
}
function libraryItem(entry) {
  const item = el("div", "lib-item");
  item.dataset.title = (entry.recipe.title ?? "").toLowerCase();
  const main = el("div", "lib-main");
  main.appendChild(textEl("div", entry.recipe.title || "Untitled", "lib-title"));
  const meta = [];
  if (entry.recipe.cuisine) meta.push(entry.recipe.cuisine);
  const tags = entry.recipe.dietaryTags ?? [];
  if (tags.length) meta.push(tags.slice(0, 2).join(", "));
  meta.push(formatDate(entry.savedAt));
  main.appendChild(textEl("div", meta.filter(Boolean).join(" \xB7 "), "lib-meta"));
  main.addEventListener("click", () => openSaved(entry));
  item.appendChild(main);
  const del = textEl("button", "\u2715", "row-remove");
  del.title = "Delete";
  del.addEventListener("click", (e) => {
    e.stopPropagation();
    void deleteRecipe(entry.videoId).then(() => item.remove());
  });
  item.appendChild(del);
  return item;
}
function openSaved(entry) {
  loadRecipeIntoView(structuredClone(entry.recipe), entry.videoId);
}
function formatDate(ms) {
  if (!ms) return "";
  return new Date(ms).toLocaleDateString();
}
var MACRO_COLORS = { protein: "#3b82f6", carbs: "#f59e0b", fat: "#ef4444" };
function nutritionRing(n) {
  const p = n.protein ?? 0;
  const c = n.carbs ?? 0;
  const f = n.fat ?? 0;
  const cals = { protein: p * 4, carbs: c * 4, fat: f * 9 };
  const total = cals.protein + cals.carbs + cals.fat;
  const kcal = n.calories ?? (total > 0 ? Math.round(total) : null);
  const size = 76;
  const cx = size / 2;
  const r = 28;
  const circ = 2 * Math.PI * r;
  const svg = svg_("svg", { width: size, height: size, viewBox: `0 0 ${size} ${size}` });
  svg.appendChild(svg_("circle", { cx, cy: cx, r, fill: "none", stroke: "var(--line)", "stroke-width": 8 }));
  if (total > 0) {
    let offset = 0;
    for (const key of ["protein", "carbs", "fat"]) {
      const len = cals[key] / total * circ;
      if (len <= 0) continue;
      svg.appendChild(svg_("circle", {
        cx,
        cy: cx,
        r,
        fill: "none",
        stroke: MACRO_COLORS[key],
        "stroke-width": 8,
        "stroke-dasharray": `${len} ${circ - len}`,
        "stroke-dashoffset": `${-offset}`,
        transform: `rotate(-90 ${cx} ${cx})`
      }));
      offset += len;
    }
  }
  if (kcal !== null) {
    const t = svg_("text", { x: cx, y: cx - 1, "text-anchor": "middle", "dominant-baseline": "middle", "font-size": 14, "font-weight": 600, fill: "var(--fg)" });
    t.textContent = String(kcal);
    svg.appendChild(t);
    const u = svg_("text", { x: cx, y: cx + 12, "text-anchor": "middle", "font-size": 8, fill: "var(--muted)" });
    u.textContent = "kcal";
    svg.appendChild(u);
  }
  const row = el("div", "nutri-row");
  row.appendChild(svg);
  const legend = el("div", "nutri-legend");
  legend.append(
    macroLegend("Protein", n.protein, MACRO_COLORS.protein),
    macroLegend("Carbs", n.carbs, MACRO_COLORS.carbs),
    macroLegend("Fat", n.fat, MACRO_COLORS.fat)
  );
  row.appendChild(legend);
  return row;
}
function macroLegend(label, grams, color) {
  const item = el("div", "nutri-item");
  const dot = el("span", "nutri-dot");
  dot.style.background = color;
  item.append(dot, document.createTextNode(`${label}: ${grams === null ? "\u2014" : `${grams} g`}`));
  return item;
}
function svg_(name, attrs) {
  const e = document.createElementNS("http://www.w3.org/2000/svg", name);
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, String(v));
  return e;
}
function renderCard() {
  renderRoot();
}
function card(r) {
  const frag = document.createDocumentFragment();
  const head = el("div", "head");
  const nav = el("div", "nav");
  const savedBtn = textEl("button", "\u2630 Saved recipes", "icon-btn");
  savedBtn.addEventListener("click", openLibrary);
  nav.appendChild(savedBtn);
  head.appendChild(nav);
  const top = el("div", "top");
  const title = textEl("h1", r.title, "title");
  if (editMode) makeEditable(title, "r-title", "Recipe title");
  top.appendChild(title);
  const conf = textEl("span", `${r.sourceConfidence}`, "conf");
  conf.classList.add(r.sourceConfidence);
  top.appendChild(conf);
  head.appendChild(top);
  head.appendChild(chips(r));
  const pills = dietaryPills(r);
  if (pills) head.appendChild(pills);
  if (!editMode) head.appendChild(controlsRow());
  head.appendChild(controlBar());
  head.appendChild(tabBar(r));
  frag.appendChild(head);
  frag.appendChild(tabBody(r));
  frag.appendChild(textEl("div", "", "status"));
  return frag;
}
function dietaryPills(r) {
  const tags = r.dietaryTags ?? [];
  if (tags.length === 0) return null;
  const wrap = el("div", "pills");
  for (const tag of tags) wrap.appendChild(textEl("span", tag, "pill"));
  return wrap;
}
function tabBar(r) {
  const bar = el("div", "tabbar");
  const tabs = [
    ["ingredients", `Ingredients \xB7 ${r.ingredients.length}`],
    ["steps", `Steps \xB7 ${r.steps.length}`],
    ["overview", "Overview"]
  ];
  for (const [key, label] of tabs) {
    const tab = textEl("button", label, "tab");
    if (key === activeTab) tab.classList.add("on");
    tab.addEventListener("click", () => {
      if (editMode) readDomIntoRecipe();
      activeTab = key;
      renderCard();
    });
    bar.appendChild(tab);
  }
  return bar;
}
function tabBody(r) {
  const body = el("div", "tabbody");
  if (activeTab === "ingredients") body.appendChild(ingredientsBody(r));
  else if (activeTab === "steps") body.appendChild(stepsBody(r));
  else body.appendChild(overviewBody(r));
  return body;
}
function overviewBody(r) {
  const wrap = el("div");
  if (editMode) {
    wrap.appendChild(textEl("div", "Summary", "ov-label"));
    const summary = textEl("div", r.summary ?? "", "notes");
    makeEditable(summary, "r-summary", "Short summary\u2026");
    wrap.appendChild(summary);
  } else if (r.summary) {
    wrap.appendChild(textEl("p", r.summary, "summary"));
  }
  if (!editMode && r.backstory) {
    wrap.appendChild(textEl("div", "Origin", "ov-label"));
    wrap.appendChild(textEl("p", r.backstory, "summary"));
  }
  if (!editMode && r.chefTip) {
    wrap.appendChild(textEl("div", "Chef's tip", "ov-label"));
    wrap.appendChild(textEl("p", r.chefTip, "summary"));
  }
  const facts = [];
  if (r.difficulty) facts.push(`Difficulty: ${r.difficulty}`);
  if (r.cuisine) facts.push(`Cuisine: ${r.cuisine}`);
  if (facts.length) wrap.appendChild(textEl("div", facts.join("  \xB7  "), "ov-facts"));
  if (!editMode && r.nutrition) {
    wrap.appendChild(textEl("div", "Nutrition \xB7 estimate, per serving", "ov-label"));
    wrap.appendChild(nutritionRing(r.nutrition));
  }
  const equipment = r.equipment ?? [];
  if (equipment.length) {
    wrap.appendChild(textEl("div", "Equipment", "ov-label"));
    const list = el("div", "pills");
    for (const item of equipment) list.appendChild(textEl("span", item, "pill"));
    wrap.appendChild(list);
  }
  if (editMode) {
    wrap.appendChild(textEl("div", "Notes", "ov-label"));
    const notes = textEl("div", r.notes ?? "", "notes");
    makeEditable(notes, "r-notes", "Add notes\u2026");
    wrap.appendChild(notes);
  } else if (r.notes) {
    wrap.appendChild(textEl("div", "Notes", "ov-label"));
    wrap.appendChild(textEl("div", r.notes, "notes"));
  }
  if (!wrap.hasChildNodes()) {
    wrap.appendChild(textEl("p", "No extra details for this recipe.", "summary"));
  }
  return wrap;
}
function chips(r) {
  const wrap = el("div", "chips");
  if (editMode) {
    const serves = el("span", "chip");
    serves.append(
      document.createTextNode("\u{1F37D} Serves "),
      makeEditable(textEl("span", r.servings ?? ""), "r-servings", "?")
    );
    const time = el("span", "chip");
    time.append(
      document.createTextNode("\u23F1 "),
      makeEditable(textEl("span", r.totalTime ?? ""), "r-totaltime", "total time")
    );
    wrap.append(serves, time);
    return wrap;
  }
  if (r.servings) {
    wrap.appendChild(textEl("span", `\u{1F37D} Serves ${scaleServings(r.servings, scale)}`, "chip"));
  }
  if (r.totalTime) {
    wrap.appendChild(textEl("span", `\u23F1 ${r.totalTime}`, "chip"));
  }
  return wrap;
}
function controlsRow() {
  const wrap = el("div", "controls");
  const scaleCtl = el("div", "ctl");
  scaleCtl.appendChild(textEl("span", "Scale", "lbl"));
  const scaleSeg = el("div", "seg accent");
  for (const factor of [0.5, 1, 2]) {
    const btn = textEl("button", factor === 1 ? "1\xD7" : factor === 0.5 ? "\xBD\xD7" : "2\xD7");
    if (factor === scale) btn.classList.add("on");
    btn.addEventListener("click", () => {
      scale = factor;
      renderCard();
    });
    scaleSeg.appendChild(btn);
  }
  scaleCtl.appendChild(scaleSeg);
  wrap.appendChild(scaleCtl);
  const unitCtl = el("div", "ctl");
  unitCtl.appendChild(textEl("span", "Units", "lbl"));
  const unitSeg = el("div", "seg accent");
  const opts = [["orig", "Orig"], ["us", "US"], ["metric", "Metric"]];
  for (const [sys, label] of opts) {
    const btn = textEl("button", label);
    if (sys === units) btn.classList.add("on");
    btn.addEventListener("click", () => {
      units = sys;
      renderCard();
    });
    unitSeg.appendChild(btn);
  }
  unitCtl.appendChild(unitSeg);
  wrap.appendChild(unitCtl);
  return wrap;
}
function controlBar() {
  const bar = el("div", "bar");
  const seg = el("div", "seg");
  const viewBtn = textEl("button", "View");
  const editBtn = textEl("button", "Edit");
  (editMode ? editBtn : viewBtn).classList.add("on");
  viewBtn.addEventListener("click", () => setEditMode(false));
  editBtn.addEventListener("click", () => setEditMode(true));
  seg.append(viewBtn, editBtn);
  bar.appendChild(seg);
  const actions = el("div", "actions");
  actions.append(
    actionBtn("Copy", onCopy),
    actionBtn("Export", onExport),
    actionBtn("Save", onSave)
  );
  bar.appendChild(actions);
  return bar;
}
function openLibrary() {
  libraryOpen = true;
  renderRoot();
}
function ingredientsBody(r) {
  const wrap = el("div");
  r.ingredients.forEach((ing, i) => {
    const row = el("div", "row");
    if (editMode) {
      const edit = el("div", "ing-edit");
      edit.append(
        makeEditable(textEl("span", ing.amount ?? "", "ing-amount"), void 0, "qty"),
        makeEditable(textEl("span", ing.unit ?? "", "ing-unit"), void 0, "unit"),
        makeEditable(textEl("span", ing.name, "ing-name"), void 0, "ingredient")
      );
      row.append(edit, uncertainToggle(ing.uncertain), removeButton(row));
    } else {
      if (checkedIngredients.has(i)) row.classList.add("done");
      row.classList.add("ing-col");
      const line = el("div", "ing-line");
      const check = textEl("span", "\u2713", "check");
      check.addEventListener("click", () => toggleCheck(row, check, checkedIngredients, i));
      const text = el("span", "text");
      const m = convertMeasure(ing.amount, ing.unit, units, scale);
      const qty = [m.amount, m.unit].filter(Boolean).join(" ");
      if (qty) text.appendChild(textEl("span", qty + " ", "amount"));
      text.appendChild(document.createTextNode(ing.name));
      if (ing.uncertain) text.appendChild(textEl("span", "approx", "tag"));
      const subs = el("div", "subs");
      const swap = textEl("button", "\u21C4", "swap");
      swap.title = "Find substitutions";
      swap.addEventListener("click", () => void toggleSubs(ing.name, subs, swap));
      line.append(check, text, swap);
      row.append(line, subs);
    }
    wrap.appendChild(row);
  });
  if (editMode) {
    wrap.appendChild(addRow("+ ingredient", () => {
      readDomIntoRecipe();
      recipe?.ingredients.push({ name: "", amount: null, unit: null, uncertain: false });
      renderCard();
    }));
  }
  return wrap;
}
function stepsBody(r) {
  const wrap = el("div");
  r.steps.forEach((step, i) => {
    const row = el("div", "row");
    if (step.timestamp !== null) row.dataset.ts = String(step.timestamp);
    if (editMode) {
      row.append(
        textEl("span", String(i + 1), "num"),
        makeEditable(textEl("div", step.instruction, "step-text text"), void 0, "step\u2026"),
        removeButton(row)
      );
    } else {
      if (checkedSteps.has(i)) row.classList.add("done");
      const num = textEl("span", checkedSteps.has(i) ? "\u2713" : String(i + 1), "num");
      num.addEventListener("click", () => {
        const on = toggleCheck(row, null, checkedSteps, i);
        num.textContent = on ? "\u2713" : String(i + 1);
      });
      const col = el("div", "text");
      col.appendChild(textEl("div", convertInText(step.instruction, units, scale)));
      if (step.timestamp !== null) col.appendChild(timestampPill(step.timestamp));
      row.append(num, col);
    }
    wrap.appendChild(row);
  });
  if (editMode) {
    wrap.appendChild(addRow("+ step", () => {
      readDomIntoRecipe();
      recipe?.steps.push({ instruction: "", timestamp: null });
      renderCard();
    }));
  }
  return wrap;
}
function setEditMode(on) {
  if (on === editMode) return;
  if (!on) readDomIntoRecipe();
  editMode = on;
  renderCard();
}
function toggleCheck(row, check, set, index) {
  const now = !set.has(index);
  if (now) set.add(index);
  else set.delete(index);
  row.classList.toggle("done", now);
  persistChecks();
  return now;
}
function persistChecks() {
  if (!videoId) return;
  const checks = {
    ingredients: [...checkedIngredients],
    steps: [...checkedSteps]
  };
  void saveChecks(videoId, checks);
}
function timestampPill(seconds) {
  const pill = textEl("button", `\u25B6 ${formatTimestamp(seconds)}`, "ts");
  pill.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "SEEK", seconds }).catch(() => {
    });
  });
  return pill;
}
async function onCopy() {
  await navigator.clipboard.writeText(toMarkdown(effectiveRecipe()));
  setStatus("Copied to clipboard.");
}
function onExport() {
  const r = effectiveRecipe();
  const blob = new Blob([toMarkdown(r)], { type: "text/markdown" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${slugify(r.title) || "recipe"}.md`;
  a.click();
  URL.revokeObjectURL(url);
  setStatus("Markdown downloaded.");
}
async function onSave() {
  if (!videoId || !recipe) return;
  if (editMode) readDomIntoRecipe();
  await saveRecipe(videoId, recipe);
  setStatus("Saved.");
}
async function toggleSubs(name, container, swap) {
  if (container.childElementCount > 0) {
    container.replaceChildren();
    swap.classList.remove("on");
    return;
  }
  swap.classList.add("on");
  container.replaceChildren(textEl("div", "Finding substitutions\u2026", "sub-loading"));
  try {
    const res = await fetch(SUBSTITUTE_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ dish: recipe?.title ?? "", ingredient: name })
    });
    const data = await res.json();
    if (!data.ok) {
      container.replaceChildren(textEl("div", data.message, "sub-loading"));
      return;
    }
    if (data.substitutions.length === 0) {
      container.replaceChildren(textEl("div", "No substitutions found.", "sub-loading"));
      return;
    }
    container.replaceChildren();
    for (const s of data.substitutions) {
      const item = el("div", "sub-item");
      item.appendChild(textEl("span", s.substitute, "sub-name"));
      if (s.note) item.appendChild(textEl("span", ` \u2014 ${s.note}`, "sub-note"));
      container.appendChild(item);
    }
  } catch {
    container.replaceChildren(textEl("div", "Couldn't load substitutions.", "sub-loading"));
  }
}
function effectiveRecipe() {
  if (editMode) readDomIntoRecipe();
  const base = recipe;
  return {
    ...base,
    servings: scaleServings(base.servings, scale),
    ingredients: base.ingredients.map((ing) => {
      const m = convertMeasure(ing.amount, ing.unit, units, scale);
      return { ...ing, amount: m.amount, unit: m.unit };
    }),
    steps: base.steps.map((s) => ({
      ...s,
      instruction: convertInText(s.instruction, units, scale)
    }))
  };
}
function readDomIntoRecipe() {
  if (!recipe) return;
  const updated = { ...recipe };
  const titleEl = app.querySelector(".r-title");
  if (titleEl) updated.title = readText(titleEl) || recipe.title;
  const servEl = app.querySelector(".r-servings");
  if (servEl) updated.servings = readText(servEl) || null;
  const timeEl = app.querySelector(".r-totaltime");
  if (timeEl) updated.totalTime = readText(timeEl) || null;
  if (activeTab === "ingredients") {
    updated.ingredients = Array.from(app.querySelectorAll(".ing-edit")).map((edit) => ({
      amount: readText(edit.querySelector(".ing-amount")) || null,
      unit: readText(edit.querySelector(".ing-unit")) || null,
      name: readText(edit.querySelector(".ing-name")),
      uncertain: !!edit.parentElement?.querySelector(".uncertain.on")
    })).filter((i) => i.name !== "");
  }
  if (activeTab === "steps") {
    updated.steps = Array.from(app.querySelectorAll(".row")).filter((row) => row.querySelector(".step-text")).map((row) => ({
      instruction: readText(row.querySelector(".step-text")),
      timestamp: row.dataset.ts !== void 0 ? Number(row.dataset.ts) : null
    })).filter((s) => s.instruction !== "");
  }
  if (activeTab === "overview") {
    const sumEl = app.querySelector(".r-summary");
    if (sumEl) updated.summary = readText(sumEl) || null;
    const notesEl = app.querySelector(".r-notes");
    if (notesEl) updated.notes = readText(notesEl) || null;
  }
  recipe = updated;
}
function uncertainToggle(on) {
  const chip = textEl("span", "approx", "uncertain tag");
  chip.title = "Toggle uncertain amount";
  chip.style.opacity = on ? "1" : "0.4";
  if (on) chip.classList.add("on");
  chip.addEventListener("click", () => {
    chip.style.opacity = chip.classList.toggle("on") ? "1" : "0.4";
  });
  return chip;
}
function removeButton(row) {
  const btn = textEl("button", "\u2715", "row-remove");
  btn.title = "Remove";
  btn.addEventListener("click", () => {
    row.remove();
    readDomIntoRecipe();
  });
  return btn;
}
function addRow(label, onClick) {
  const btn = textEl("button", label, "add-row");
  btn.addEventListener("click", onClick);
  return btn;
}
function actionBtn(label, onClick) {
  const btn = textEl("button", label, "icon-btn");
  btn.addEventListener("click", () => void onClick());
  return btn;
}
function makeEditable(elm, className, placeholder) {
  if (className) elm.classList.add(...className.split(" "));
  elm.contentEditable = "true";
  elm.dataset.ph = placeholder;
  return elm;
}
function setStatus(msg) {
  const status = app.querySelector(".status");
  if (status) status.textContent = msg;
}
function readText(elm) {
  return elm?.textContent?.trim() ?? "";
}
function slugify(s) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
function el(tag, className) {
  const e = document.createElement(tag);
  if (className) e.className = className;
  return e;
}
function textEl(tag, content, className) {
  const e = el(tag, className);
  e.textContent = content;
  return e;
}
//# sourceMappingURL=panel.js.map
